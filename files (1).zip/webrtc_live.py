"""
ARCHITECTURE SKELETON — hosted deployment via streamlit-webrtc.
=================================================================

Why this file exists
---------------------
app.py currently does `cv2.VideoCapture(0)`, which opens a camera
attached to the machine RUNNING the Streamlit server. That's fine for
local testing, but breaks the moment you host this somewhere and a
candidate connects from their own laptop — the server has no access to
their webcam.

streamlit-webrtc fixes this by using WebRTC to stream video FROM the
candidate's browser TO the server. You define a VideoProcessorBase
subclass whose recv() method is called once per incoming frame, on a
background thread managed by the component — similar in spirit to the
LatestFrameCamera thread we built for the local version, except the
"camera" is now the candidate's browser and the frame delivery is
push-based instead of us polling cv2.VideoCapture.

Install (not needed in this sandbox, but required wherever you actually
run this):
    pip install streamlit-webrtc aiortc av

Key structural differences from app.py
---------------------------------------
1. No cv2.VideoCapture / LatestFrameCamera — webrtc_streamer() owns
   the frame pump.
2. process_frame() now runs INSIDE recv(), on streamlit-webrtc's
   thread — not in a while-loop in the main script.
3. recv() must NOT call Streamlit widgets directly (st.markdown, etc.)
   — that's a different thread. It writes results to session_store on
   disk (same as before) and to a thread-safe attribute the main
   script can poll.
4. The main script becomes much lighter: just render the webrtc
   component, then periodically read the latest analysis to update the
   side panels — no heavy inference in this thread at all.
5. For real hosting you also need:
   - HTTPS (browsers require a secure context for camera access,
     except on localhost)
   - A STUN server for NAT traversal (default below uses a public
     Google STUN server, fine for testing)
   - A TURN server for production — STUN alone fails on many
     corporate/restrictive networks; without TURN some candidates
     simply won't connect. Options: coturn (self-hosted), Twilio
     Network Traversal Service, Cloudflare Calls, etc.
"""

import time
import queue
import threading

import av
import cv2
import streamlit as st
from streamlit_webrtc import webrtc_streamer, VideoProcessorBase, RTCConfiguration

from detection import process_frame
import session_store


def get_ice_servers():
    """STUN config for NAT traversal. Swap/add a TURN server here for
    production — see module docstring above."""
    return RTCConfiguration({
        "iceServers": [{"urls": ["stun:stun.l.google.com:19302"]}]
    })


class InterviewVideoProcessor(VideoProcessorBase):
    """
    Runs process_frame() on every incoming browser frame. Keeps its own
    throttling state (equivalent to PROCESS_EVERY_N_FRAMES / the
    YOLO/YuNet throttling already inside detection.py) since this
    instance is per-connection, not a shared module-level loop.
    """

    def __init__(self):
        self.frame_count = 0
        self.process_every_n_frames = 3
        self.last_analysis = None

        self.last_json_update = 0.0
        self.json_update_interval = 1.0

        self.violation_cooldown = 5.0
        self._last_violation_time = {}

        # Thread-safe handoff to the main Streamlit script thread, which
        # polls this instead of touching st.* widgets from here.
        self.latest_result_lock = threading.Lock()
        self.latest_result = None

    def _maybe_log_violation(self, frame_bgr, violation_type, is_active):
        if not is_active:
            return
        last = self._last_violation_time.get(violation_type, 0)
        if time.time() - last >= self.violation_cooldown:
            session_store.save_violation(frame_bgr, violation_type)
            self._last_violation_time[violation_type] = time.time()

    def recv(self, frame: av.VideoFrame) -> av.VideoFrame:
        img = frame.to_ndarray(format="bgr24")
        self.frame_count += 1

        if self.frame_count % self.process_every_n_frames == 0 or self.last_analysis is None:
            img, analysis = process_frame(img)
            self.last_analysis = analysis

            self._maybe_log_violation(img, "Phone Detected", analysis["objects"]["phone_detected"])
            self._maybe_log_violation(img, "Face Covered/Missing", analysis["behavior"]["face_missing"])
            self._maybe_log_violation(img, "Object On Face", analysis["objects"]["object_on_face"])
            self._maybe_log_violation(img, "Multiple Faces", analysis["behavior"]["multiple_faces"])
        else:
            analysis = self.last_analysis

        now = time.time()
        if now - self.last_json_update >= self.json_update_interval:
            session_store.append_timeline(analysis["attention"]["status"], fps=0)
            self.last_json_update = now

        with self.latest_result_lock:
            self.latest_result = analysis

        # Returning the (possibly annotated) frame sends it back to the
        # browser for display — this replaces frame_placeholder.image()
        # entirely; the component renders the video natively.
        return av.VideoFrame.from_ndarray(img, format="bgr24")

    def get_latest_result(self):
        with self.latest_result_lock:
            return self.latest_result


# --------------------------------------------------
# Page
# --------------------------------------------------

st.set_page_config(page_title="Interview Intelligence (Hosted)", page_icon="🎯", layout="wide")
st.title("🎯 Interview Intelligence — Hosted (WebRTC)")
st.caption(
    "Reference skeleton: candidate's browser captures video and streams it "
    "here via WebRTC, instead of the server reading a local webcam."
)

left, right = st.columns([2, 1])

with left:
    ctx = webrtc_streamer(
        key="interview-stream",
        video_processor_factory=InterviewVideoProcessor,
        rtc_configuration=get_ice_servers(),
        media_stream_constraints={"video": True, "audio": False},
    )

with right:
    st.subheader("Live Status")
    status_box = st.empty()

    # Lightweight polling loop. Note: unlike the old app.py loop, there's
    # no camera reading or model inference happening here at all — that
    # all happens inside recv() on the webrtc thread. This loop just
    # checks in periodically to refresh the panel, so it can safely use
    # a short sleep without risking the busy-spin/freeze issue from the
    # local version.
    if ctx.state.playing and ctx.video_processor:
        while ctx.state.playing:
            result = ctx.video_processor.get_latest_result()
            if result:
                status_box.markdown(f"""
#### {'🟢' if result['attention']['status'] == 'Focused' else '🔴'} {result['attention']['status']}

| Parameter | Value |
|---|---|
| Looking at Screen | {result['attention']['looking_at_screen']} |
| Head Direction | {result['attention']['head_direction']} |
| Face Detected | {result['face']['detected']} |
| Phone Detected | {result['objects']['phone_detected']} |
""")
            time.sleep(1)
    else:
        st.info("Click START above to connect your camera.")

st.divider()
st.caption(
    "This page intentionally reuses session_store.py, so the Session Report "
    "and Interviewer Dashboard pages work unchanged against a hosted session."
)
