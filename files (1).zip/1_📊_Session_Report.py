import streamlit as st
import pandas as pd

import session_store

st.set_page_config(page_title="Session Report", page_icon="📊", layout="wide")

st.title("📊 Session Report")
st.caption("Reads from disk, so this reflects the full session even if you weren't on the Live Monitoring tab the whole time.")

col_refresh, col_clear = st.columns([1, 1])
with col_refresh:
    if st.button("🔄 Refresh"):
        st.rerun()
with col_clear:
    if st.button("🗑️ Clear entire session (timeline + all snapshots)", type="secondary"):
        session_store.clear_timeline()
        session_store.clear_all_violations()
        st.rerun()

st.divider()

# --------------------------------------------------
# Timeline chart
# --------------------------------------------------

st.subheader("Attention Timeline")

timeline_df = session_store.load_timeline()

if timeline_df.empty:
    st.info("No timeline data yet — start the Live Monitoring page to begin recording.")
else:
    focused_pct = (timeline_df["status"] == "Focused").mean() * 100
    distracted_pct = (timeline_df["status"] == "Distracted").mean() * 100
    duration_min = (timeline_df["epoch"].max() - timeline_df["epoch"].min()) / 60

    m1, m2, m3 = st.columns(3)
    m1.metric("Session Duration", f"{duration_min:.1f} min")
    m2.metric("% Time Focused", f"{focused_pct:.0f}%")
    m3.metric("% Time Distracted", f"{distracted_pct:.0f}%")

    chart_df = timeline_df.set_index("timestamp")[["score_numeric"]]
    chart_df.columns = ["Attention (1=Focused, 0=Distracted, -1=Unknown)"]
    st.line_chart(chart_df)

    with st.expander("Raw timeline data"):
        st.dataframe(timeline_df, use_container_width=True)

st.divider()

# --------------------------------------------------
# Violations
# --------------------------------------------------

st.subheader("Violations")

violations = session_store.load_violations()
counts = session_store.violation_counts()

if not violations:
    st.success("No violations recorded.")
else:
    count_cols = st.columns(max(len(counts), 1))
    for col, (vtype, n) in zip(count_cols, counts.items()):
        col.metric(vtype, n)

    st.write("")

    for record in violations:
        with st.container(border=True):
            img_col, info_col = st.columns([1, 2])

            with img_col:
                img_path = session_store.load_violation_image_path(record)
                st.image(img_path, use_container_width=True)

            with info_col:
                st.markdown(f"**{record['type']}**")
                st.caption(record["timestamp"])
                if st.button("🗑️ Delete", key=f"delete_{record['id']}"):
                    session_store.delete_violation(record["id"])
                    st.rerun()
