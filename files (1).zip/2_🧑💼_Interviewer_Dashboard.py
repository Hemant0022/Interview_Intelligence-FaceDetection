import streamlit as st
import pandas as pd

import session_store

st.set_page_config(page_title="Interviewer Dashboard", page_icon="🧑‍💼", layout="wide")

st.title("🧑‍💼 Interviewer Dashboard")
st.caption(
    "Summary view for reviewing a candidate's session. This reads from disk, "
    "so it works whether or not the Live Monitoring tab is currently open."
)

if st.button("🔄 Refresh"):
    st.rerun()

st.divider()

timeline_df = session_store.load_timeline()
violations = session_store.load_violations()
counts = session_store.violation_counts()

if timeline_df.empty:
    st.info("No session data yet — open the Live Monitoring page to start recording.")
    st.stop()

# --------------------------------------------------
# Current status
# --------------------------------------------------

latest = timeline_df.iloc[-1]
status_icon = "🟢" if latest["status"] == "Focused" else ("🔴" if latest["status"] == "Distracted" else "⚪")

st.subheader(f"{status_icon} Current Status: {latest['status']}")
st.caption(f"Last updated {latest['timestamp']}")

st.divider()

# --------------------------------------------------
# Summary metrics
# --------------------------------------------------

st.subheader("Session Summary")

focused_pct = (timeline_df["status"] == "Focused").mean() * 100
distracted_pct = (timeline_df["status"] == "Distracted").mean() * 100
duration_min = (timeline_df["epoch"].max() - timeline_df["epoch"].min()) / 60
total_violations = sum(counts.values())

m1, m2, m3, m4 = st.columns(4)
m1.metric("Duration", f"{duration_min:.1f} min")
m2.metric("% Focused", f"{focused_pct:.0f}%")
m3.metric("% Distracted", f"{distracted_pct:.0f}%")
m4.metric("Total Violations", total_violations)

if counts:
    st.write("**Violation breakdown:**")
    breakdown_cols = st.columns(len(counts))
    for col, (vtype, n) in zip(breakdown_cols, counts.items()):
        col.metric(vtype, n)

st.divider()

# --------------------------------------------------
# History table + export
# --------------------------------------------------

st.subheader("Session History")

st.dataframe(timeline_df, use_container_width=True, height=300)

csv_data = timeline_df.to_csv(index=False).encode("utf-8")
st.download_button(
    "⬇️ Download timeline as CSV",
    data=csv_data,
    file_name="session_timeline.csv",
    mime="text/csv"
)

if violations:
    st.write("")
    st.write("**Recent violations:**")
    violations_df = pd.DataFrame(violations)[["timestamp", "type"]]
    st.dataframe(violations_df, use_container_width=True, height=200)
    st.caption("See the Session Report tab to view/delete individual snapshots.")
