# Going from local to hosted: what actually changes

## The core problem

`app.py` calls `cv2.VideoCapture(0)`, which opens a camera physically
attached to whatever machine is running the Streamlit **server**. That's
fine when you run it on your own laptop. It breaks the moment you deploy
this somewhere and a candidate connects from *their* machine — the
server has no access to their webcam, only to its own (or none at all,
if it's a cloud VM).

## The fix: browser-side capture via WebRTC

`streamlit-webrtc` (built on `aiortc`) lets the **candidate's browser**
capture their webcam and stream it to the server over a real-time
peer connection. The server processes incoming frames and can stream
annotated video back. See `webrtc_live.py` for a working skeleton.

## What changes structurally

| | Local (`app.py`) | Hosted (`webrtc_live.py`) |
|---|---|---|
| Frame source | `cv2.VideoCapture(0)` on the server | Candidate's browser, via WebRTC |
| Frame delivery | Server polls the camera (we built a threaded reader to avoid buffering lag) | Browser pushes frames; `recv()` is called per frame |
| Where inference runs | Main script's `while` loop | `VideoProcessor.recv()`, on a thread managed by the component |
| Displaying video | `frame_placeholder.image()` called every frame | The component displays frames natively; `recv()` can return an annotated frame |
| Updating side panels | Direct `st.markdown()` calls in the same loop | Main thread **polls** a thread-safe attribute on the processor — `recv()` itself must never call `st.*` directly, since it runs on a different thread |
| Session Report / Dashboard pages | Read from `session_store.py` | **Unchanged** — same `session_store.py`, so these pages work as-is |

## Requirements for real hosting

1. **HTTPS.** Browsers block camera access (`getUserMedia`) on insecure
   origins, except `localhost`. Any real deployment needs TLS.
2. **STUN server** for NAT traversal — `webrtc_live.py` ships a default
   public Google STUN server, which is enough for testing.
3. **TURN server** for production. STUN alone fails whenever a
   candidate is behind certain corporate firewalls or restrictive NATs
   — without TURN as a fallback relay, some fraction of candidates
   simply won't be able to connect at all. This is usually the single
   biggest gap between "works on my machine" and "works for everyone."
   Options: self-hosted `coturn`, or a managed service (Twilio Network
   Traversal Service, Cloudflare Calls, etc).
4. **Per-connection state**, not module-level globals. In the local
   version, throttling counters (`frame_count`, cached YOLO/YuNet
   results) live as module-level state because there's only ever one
   camera. In the hosted version, each candidate gets their own
   `VideoProcessor` instance — that's why `webrtc_live.py` moves that
   state onto the class instead of module globals.

## What does *not* need to change

- `detection.py` — `process_frame()` is unchanged. It doesn't care
  where the frame came from.
- `session_store.py` — same disk-backed timeline/violations store.
  Works identically whether written from the local loop or from a
  `VideoProcessor.recv()` thread.
- `pages/1_📊_Session_Report.py` and `pages/2_🧑‍💼_Interviewer_Dashboard.py`
  — both just read from `session_store`, so they work against either
  entry point without modification.

## Known limitation worth knowing about (both versions)

Monitoring only actively *runs* while its page is the one currently
open in the browser — navigating to the Session Report or Dashboard tab
pauses capture on the Live page (Streamlit re-runs/abandons the
previous page's script on navigation). Because `session_store.py`
writes to disk immediately, no already-recorded data is lost, and the
other pages will always show everything captured so far — but nothing
new gets recorded while you're not on the Live/hosted-stream page.

If you need truly continuous recording regardless of which tab an
interviewer is viewing, the next step would be to move capture out of
the Streamlit process entirely — e.g. a small standalone service (or a
separate always-running WebRTC ingest process) that writes to
`session_store` independently, with the Streamlit pages acting purely
as viewers. That's a meaningful jump in complexity and only worth it if
"pause while I look at the dashboard" is actually a problem for how
this gets used.
